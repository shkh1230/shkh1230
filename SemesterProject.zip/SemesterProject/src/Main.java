import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

class FlightPlanner {
    public static int find(LinkedList<LinkedList<FlightData>> list, String city){
        boolean found = false;
        for (int i = 0; i < list.size(); i++){
            if(list.get(i).getFirst().getCity().equals(city)){
                return i;
            }
        }
        return -1;

    }
    public static void reset(LinkedList<LinkedList<FlightData>> list){
        for (int i = 0; i < list.size(); i++){
            for(int j = 0; j < list.get(i).size(); j++){
                list.get(i).get(j).setFound(false);
            }
        }
    }

    public static void main(String args[]){

        LinkedList<LinkedList<FlightData>> list = new LinkedList<LinkedList<FlightData>>();

        try {
            PrintStream out = new PrintStream(new FileOutputStream("Output.txt"));
            System.setOut(out);
            File file = new File("FlightTest.txt");
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            String [] pipes;
            boolean flag = true;;

            while ((line = bufferedReader.readLine()) != null) {
                if (flag){
                    flag = false;
                }
                else{
                    pipes = line.split("\\|");
                    boolean found = false;
                    for (int i = 0; i < list.size() && !found; i++){
                        if(list.get(i).getFirst().getCity().equals(pipes[0])){
                            list.get(i).add(new FlightData(pipes[1],Integer.valueOf(pipes[2]), Integer.valueOf(pipes[3])));
                            found = true;
                        }
                    }
                    if (!found){
                        list.add(new LinkedList<FlightData>());
                        list.getLast().addFirst(new FlightData(pipes[0], 0, 0));
                        list.getLast().add(new FlightData(pipes[1], Integer.valueOf(pipes[2]), Integer.valueOf(pipes[3])));
                    }
                }
            }

            //get paths from city
            String source;
            String destination;
            flag = true;
            File request = new File("FlightPlan.txt");
            FileReader fileReader2 = new FileReader(request);
            BufferedReader bufferedReader2 = new BufferedReader(fileReader2);
            while ((line = bufferedReader2.readLine()) != null){
                if (flag){
                    flag = false;
                }
                else{
                    pipes = line.split("\\|");
                    source = pipes[0];
                    int index = find(list, source);
                    if (index == -1){
                        System.out.println("Sorry there are no flights from " + pipes[0]  + " to " + pipes[1]);
                    }//if no source city
                    else{
                        ArrayList<Path> paths = new ArrayList<Path>();
                        LinkedList<FlightData> sourceList = list.get(index);
                        for ( int j = 1; j < sourceList.size(); j++){
                            FlightData city = sourceList.get(j);
                            Path og = new Path(sourceList.getFirst(), sourceList.get(j));
                            paths.add(og);
                            while(((index =find(list, city.getCity()) )!= -1 )) {
                                if (list.get(index).getFirst().isfound()) {
                                    break;
                                }
                                LinkedList<FlightData> destList = list.get(index);
                                list.get(index).getFirst().setFound(true);
                                for (int k = 1; k < destList.size(); k++) {
                                    if (destList.get(k).getCity().equals(sourceList.getFirst().getCity()))
                                        continue;
                                    else {
                                        city = destList.get(k);
                                        paths.add(new Path(og, destList.get(k)));
                                    }
                                }
                            }

                        }
                        LinkedList<Path> search = new LinkedList<Path>();
                        for (int i = 0; i < paths.size(); i++){
                            if ((paths.get(i).getCities().peek().getCity()).equals(pipes[1]))
                            {
                                search.add(paths.get(i));
                            }
                        }
                        int place = 0;
                        int shortest = 10000;
                        if (pipes[2].equals("T")){
                            System.out.println("Flight: "+ pipes[0] + " to " + pipes[1] + " Time");
                            if (search.size() == 0)//no flights
                                System.out.println("Sorry, there are no flights from " + pipes[0] + " to " + pipes[1] );
                            int count = 0;
                            while (count <= 3 && search.size() > 0){
                                shortest = 1000;
                                if (search.size() == 1){
                                    search.get(0).print();
                                    break;
                                }
                                else{
                                    for (int l = 0; l < search.size(); l++){
                                        if ((search.get(l).getTime()) <= shortest){
                                            place = l;
                                            shortest = search.get(l).getTime();
                                        }
                                    }
                                    search.get(place).print();
                                    search.remove(place);
                                    count++;
                                }
                            }
                        }
                        if (pipes[2].equals("C")){
                            System.out.println("Flight: "+ pipes[0] + " to " + pipes[1] + " (Cost)");
                            if (search.size() == 0)
                                System.out.println("Sorry there are no flights from " + pipes[0] + " to " + pipes[1] );
                            {
                                int count = 0;
                                while (count <= 3 && search.size() > 0){
                                    shortest = 1000;
                                    if (search.size() == 1){
                                        search.get(0).print();
                                        break;
                                    }
                                    else{
                                        for (int l = 0; l < search.size(); l++){
                                            if ((search.get(l).getCost()) <= shortest){
                                                place = l;
                                                shortest = search.get(l).getCost();
                                            }
                                        }
                                        search.get(place).print();
                                        search.remove(place);
                                        count++;
                                    }
                                }
                            }

                        }
                        System.out.println();
                        reset(list);
                    }
                }
            }
        }
        catch(IOException e)
        {
            System.out.println("failed");
        }
    }
}
 class Path {
    private Stack<FlightData> cities;
    private int cost;
    private int time;
    private boolean found = false;

    public Path(FlightData source, FlightData destination)
    {
        cities = new Stack<FlightData> ();
        this.cities.push(source);
        this.cities.push(destination);
        this.cost = destination.getCost();
        this.time = destination.getTime();
    }
    public Path(Path path, FlightData destination){
        Stack<FlightData> list = path.getCities();
        this.cities = (Stack<FlightData>)list.clone();
        this.cities.push(destination);
        this.cost = path.getCost() + destination.getCost();
        this.time = path.getTime() + destination.getTime();

    }
    public int getTime()
    {
         return time;
     }
    public Stack<FlightData> getCities()
    {
        return cities;
    }
    public void setCity(Stack<FlightData> cities)
    {
        this.cities = cities;
    }
    public int getCost()
    {
        return cost;
    }
    public void setCost(int cost)
    {
        this.cost = cost;
    }
    public void setTime(int time)
    {
        this.time = time;
    }
    public void print(){
        ArrayList<String> cities = new ArrayList<String> ();
        Stack<FlightData> list = (Stack<FlightData>) this.cities.clone();
        while(!list.isEmpty()){
            cities.add(list.pop().getCity());
        }
        for (int i = (cities.size()-1); i >=0; i--)
        {
            if (i == 0)
                System.out.println(cities.get(i));
            else
                System.out.print(cities.get(i) + " -> ");
        }
        System.out.println("Cost: " + this.cost + " Time: " + this.time);
    }

}

 class FlightData {


    private String city;
    private int cost;
    private int time;
    boolean found;


    public FlightData(String c, int co, int ti)
    {
        this.city = c;
        this.cost = co;
        this.time= ti;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public int getCost() {
        return cost;
    }
    public void setCost(int cost) {
        this.cost = cost;
    }
    public int getTime() {
        return time;
    }
    public void setTime(int time) {
        this.time = time;
    }
    public boolean isfound() {
        return found;
    }
    public void setFound(boolean found) {
        this.found = found;
    }

}